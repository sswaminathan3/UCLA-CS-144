import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BlogService, Post } from '../blog.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  @Input() post: Post;
  
  save(username: string, post: Post): void {
    // update post
    if (this.blogService.newPosts === undefined || !this.blogService.newPosts.includes(post.postid)) {
      post.modified = new Date();
      this.blogService.updatePost(username, post);
    }
    // new post
    else {
      post.modified = new Date();
      this.blogService.newPosts = this.blogService.newPosts.filter(p => p !== post.postid);
      this.blogService.newPost(username, post);
    }
  }

  delete(username: string, post: Post): void {
    if (this.blogService.newPosts === undefined || !this.blogService.newPosts.includes(post.postid)) {
      this.blogService.deletePost(username, post.postid);
    }
    this.blogService.posts = this.blogService.posts.filter(p => p.postid !== post.postid);
    console.log(this.blogService.posts);
  }

  preview(post: Post): void {
    this.blogService.previewPost = post;
    console.log("preview: " + post)
    this.blogService.setCurrentDraft(post);
  }

  constructor(
    public blogService: BlogService,
    public router: Router,
    public activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.blogService.previewPost = null;
    this.activatedRoute.params.subscribe(routeParams => {
      console.log("refresh edit")
      this.getId();
    });
  }

  getId(): void {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    console.log("edit" + id)
    if (id > 0) {
      if (this.blogService.getCurrentDraft() === null || id !== this.blogService.getCurrentDraft().postid) {
          this.blogService.getPost(this.blogService.username, id)
          .then(value => this.blogService.setCurrentDraft(value));
      }
    }
  }
  
}
