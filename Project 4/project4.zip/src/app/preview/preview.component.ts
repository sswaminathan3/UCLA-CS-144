import { Component, OnInit } from '@angular/core';
import { Parser, HtmlRenderer } from 'commonmark';
import { Router, ActivatedRoute } from '@angular/router';
import { BlogService, Post } from '../blog.service';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {

  reader = new Parser();
  writer = new HtmlRenderer();

  constructor(
    public blogService: BlogService,
    public router: Router,
    public activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(routeParams => {
      console.log("refresh preview")
      this.getId();
    });
  }

  getId(): void {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    console.log("preview" + id)
    if (id > 0) {
      if (this.blogService.getCurrentDraft() === null || id !== this.blogService.getCurrentDraft().postid) {
        this.blogService.getPost(this.blogService.username, id)
        .then(value => {
          this.blogService.setCurrentDraft(value);
          this.blogService.previewPost = value;
        });
      }
      else if (id === this.blogService.getCurrentDraft().postid) {
        this.blogService.previewPost = this.blogService.getCurrentDraft();
      }
    }
  }

}
