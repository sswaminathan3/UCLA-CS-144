import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BlogService {

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  draft = null;

  posts: Post[];
  newPosts: number[];
  previewPost: Post;

  username = "";

  maxPostId = new Map([["cs144", 2], ["user2", 8]]);
  localMaxPostId = new Map([["cs144", 2], ["user2", 8]]);

	fetchPosts(username: string): Promise<Post[]> {
    const url = `/api/${username}`;
    return new Promise<Post[]>((resolve, reject) => {
      this.http.get<Post[]>(url)
      .subscribe( ret => { resolve(ret) },
        err => {
          if(err.status >= 400) reject(Error(err.status));
          resolve();
        })
    })
	}

  getPost(username: string, postid: number): Promise<Post> {
    const url = `/api/${username}/${postid}`;
    return new Promise<Post>((resolve, reject) => {
      this.http.get<Post>(url)
      .subscribe( ret => { resolve(ret) },
        err => {
          if(err.status >= 400) reject(Error(err.status));
          resolve();
        })
    })
  }

  newPost(username: string, post: Post): Promise<void> {
    const url = `/api/${username}/${post.postid}`;
    this.maxPostId.set(username, post.postid);
    return new Promise<void>((resolve, reject) => {
      this.http.post<void>(url, post, this.httpOptions)
      .subscribe( ret => { resolve(ret) },
        err => {
          if(err.status >= 400) reject(Error(err.status));
          resolve();
        })
    })
  }

  updatePost(username: string, post: Post): Promise<void> {
    const url = `/api/${username}/${post.postid}`;
    return new Promise<void>((resolve, reject) => {
      this.http.put<void>(url, post, this.httpOptions)
      .subscribe( ret => { resolve(ret) },
        err => {
          if(err.status >= 400) reject(Error(err.status));
          resolve();
        })
    })
  }

  deletePost(username: string, postid: number): Promise<void> {
    const url = `/api/${username}/${postid}`;
    return new Promise<void>((resolve, reject) => {
      this.http.delete<void>(url, this.httpOptions)
      .subscribe( ret => { resolve(ret) },
        err => {
          if(err.status >= 400) reject(Error(err.status));
          resolve();
        })
    })
  }

  setCurrentDraft(post: Post): void {
    console.log("current draft")
    console.log(post)
    this.draft = post;
  }

  getCurrentDraft(): Post {
    return this.draft;
  }

  constructor( private http: HttpClient ) { }

}

export class Post {
  postid: number;
  created: Date;
  modified: Date;
  title: string;
  body: string;
}
