import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { BlogService, Post } from '../blog.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  
  add(username: string): void {
    let id = 1;
    if (this.blogService.localMaxPostId.has(username)) {
      id = this.blogService.localMaxPostId.get(username)+1;
      console.log(id)
    }
    if (this.blogService.newPosts === undefined) {
      this.blogService.newPosts = [id];
    }
    else {
      this.blogService.newPosts.push(id);
    }

    let date = new Date();
    let post = { postid: id, created: date, modified: date, title: "", body: "" };
    
    this.blogService.localMaxPostId.set(username, id);
    this.blogService.setCurrentDraft(post);
    this.blogService.posts.push(post);
    this.router.navigate(['/edit', post.postid]);
  }

	parseJWT(token: string): void {
    let base64Url = token.split('.')[1];
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    let user = JSON.parse(atob(base64));
    this.blogService.username = user.usr;
    this.fetchPosts(user.usr);
  }
  
  getJWT(cookies: string): string {
    let parsed = cookies.split('=').join(';').replace(' ', '').split(';');
    for (let i = 0; i < parsed.length; i++) {
      if (parsed[i] === "jwt") {
        return parsed[i+1];
      }
    }
    return "";
  }

  constructor(
    public blogService: BlogService,
    public router: Router) { }

  ngOnInit(): void {;
    console.log("list")
    let jwt = this.getJWT(document.cookie);
    this.parseJWT(jwt);
  }

  fetchPosts(username: string): void {
    this.blogService.fetchPosts(username)
    .then(value => this.blogService.posts = value);
  }

}
