use Final

db.Students.drop()

db.createCollection("Students")

db.Students.insert({ "sid": 123456789, "name": "John Cho", "dept": "Computer Science", "title": "Designer" })
db.Students.insert({ "sid": 234567890, "name": "Megan Fox", "dept": "Residential Life", "title": "Coder" })