var createError = require('http-errors');
var express = require('express');
var path = require('path');
var logger = require('morgan');
const fetch = require('node-fetch');
var bodyParser = require('body-parser');

var app = express();

let MongoClient = require('mongodb').MongoClient;

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//
// place your code here
//

// connection URL
const url = 'mongodb://localhost:27017/Final';

// Create a new MongoClient
const client = new MongoClient(url);

let db;

// Initialize connection once, reuse the database object 
MongoClient.connect(url, { useUnifiedTopology: true }, function(err, client) {
  try {
    // create database object
    db = client.db("Final");
    console.log('Listening on port 3000');
  } catch(err) {
    res.sendStatus(500);
  }
});

app.post('/proxy', bodyParser.text({ type: "*/*" }), async(req, res) => {
    try {
        fetch('http://oak.cs.ucla.edu/classes/cs144/examples/exam/proxy/', {
            method: 'POST',
            body: req.body,
            headers: {
                'Host': 'oak.cs.ucla.edu',
                'Content-Type': 'req.headers["content-type"]',
                'Content-Length': 'req.headers["content-length"]'
            }
        })
        .then(serverRes => {
            console.log(req.body)
            if (serverRes.body == null) {
                res.set('Host', 'localhost:3000');
                res.status(serverRes.status).send();
            }

            serverRes.buffer()
            .then(text => {
                console.log(text);

                let type = serverRes.headers.get('Content-Type');
                console.log(type)
                let length = serverRes.headers.get('Content-Length');
                console.log(length)

                res.status(serverRes.status);
                res.set('Host', 'localhost:3000');
                res.set('Content-Type', type);
                res.set('Content-Length', length);
                res.send(text);
            })      
        });
    } catch(err) {
        console.log(err);
    }
})

var getStudentApi = function(req, res) {
    return new Promise((resolve) => {
        // request does not include sid query string
        if (req.query.sid === undefined) {
            res.sendStatus(404);
            return;
        }

        try {
            let student = db.collection('Students').find({ sid: parseInt(req.query.sid) }).toArray();
            resolve(student);
        } catch(err) {
            // error while retrieving data from mongodb
            res.sendStatus(500);
            return;
        }   
    });
}

app.get('/api', async(req, res) => {
    try {
        // find student given sid query string
        let student = await getStudentApi(req, res);
        console.log(student)

        // no matching student exists
        if (student.length <= 0) {
            res.sendStatus(404);
            return;
        }

        delete student[0]._id;
        console.log(student)
        res.set('Content-Type', 'application/json');
        // don't need to set content-length because will be set for us (json)
        res.status(200).json(student[0]);
    } catch(err) {
        console.log(err)
    }
})

var getStudent = function(req, res, next) {
    return new Promise((resolve) => {
        // request does not include sid query string
        if (req.query.sid === undefined) {
            var err = new Error('Not Found');
            err.status = 404;
            next(err);
            return;
        }

        try {
            let student = db.collection('Students').find({ sid: parseInt(req.query.sid) }).toArray();
            resolve(student);
        } catch(err) {
            // error while retrieving data from mongodb
            var err = new Error('Internal Server Error');
            err.status = 500;
            next(err);
            return;
        }   
    });
}

app.get('/student', async(req, res, next) => {
    try {
        // find student given sid query string
        let student = await getStudent(req, res, next);
        console.log(student)

        // no matching student exists
        if (student.length <= 0) {
            var err = new Error('Not Found');
            err.status = 404;
            next(err);
            return;
        }

        res.status(200).render('student', { name: student[0].name, sid: student[0].sid, dept: student[0].dept, title: student[0].title });
    } catch(err) {
        console.log(err)
    }
})

app.all('*', async(req, res) => {
    res.redirect('/student/?sid=123456789');
})

app.use((err, req, res, next) => {
    console.log("message " + err.message)
    console.log("status " + err.status)
    console.log("stack " + err.stack)

    res.status(err.status || 500).render('error', { message: err.message, error: err });
});

module.exports = app;
