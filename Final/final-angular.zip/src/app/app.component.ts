import { Component } from '@angular/core';
import { FetchService } from './fetch.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'final-angular';
  list: string[];

  ngOnInit(): void {
    this.fetchService.get('http://oak.cs.ucla.edu/classes/cs144/examples/exam/angular/load/')
    .then(value => this.list = value);
  }

  refresh(): void {
    this.fetchService.get('http://oak.cs.ucla.edu/classes/cs144/examples/exam/angular/refresh/')
    .then(value => this.list = value);
  }
  

  constructor(public fetchService: FetchService) { }
}
