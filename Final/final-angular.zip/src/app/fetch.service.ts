import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FetchService {

  constructor( private http: HttpClient ) { }

  get(url: string): Promise<string[]> { 
    return new Promise<string[]>((resolve) => {
      this.http.get<string[]>(url, { observe: 'response' })
      .subscribe(response => {
        if (response.status < 200 || response.status >= 300) {
          resolve([]);
        }
        console.log(response)
        console.log(response.body)
        resolve(response.body);
      },
      err => {
        resolve([]);
      })
    }) 
  }

}
